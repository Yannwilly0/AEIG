const express = require('express');
const frcontroller = require('../controllers/frcontroller');

const router = express.Router();

router.get('/',frcontroller.getAcceuil);
router.get('/apprendre',frcontroller.getApprendre);
router.get('/Apropos',frcontroller.getApropos);
router.get('/pratique',frcontroller.getPratique);
router.get('/enregistrement',frcontroller.getEnregistrement);
router.get('/paiement',frcontroller.getPaiement);
router.get('/connect',frcontroller.getConnect);


module.exports = router;