exports.getAcceuil= (req, res, next) => {
    res.render('fr/pagefr', {
      pageTitle: 'TopFrench-Learning Acceuil',
      path: '/'
    });
};
exports.getConnect = (req, res, next) => {
  res.render('fr/connect', {
    pageTitle: 'TopFrench-Learning identification',
    path: '/connect'
  });
};
exports.getPaiement = (req, res, next) => {
res.render('fr/paiement', {
  pageTitle: 'TopFrench-Learning Paiement',
  path: '/paiement'
});
};
exports.getEnregistrement = (req, res, next) => {
res.render('fr/enregistrement', {
  pageTitle: 'TopFrench-Learning Enregistrement',
  path: '/enregistrement'
});
};
exports.getPratique = (req, res, next) => {
res.render('fr/pratique', {
  pageTitle: 'TopFrench-Learning Cours de pratique',
  path: '/services'
});
};

exports.getApprendre = (req, res, next) => {
res.render('fr/apprendre', {
  pageTitle: 'TopFrench-Learning Cours d\'apprentissage',
  path: '/services'
});
};
exports.getApropos = (req, res, next) => {
res.render('fr/Apropos', {
  pageTitle: 'TopFrench-Learning A propos',
  path: '/Apropos'
});
};
exports.getApropos = (req, res, next) => {
res.render('fr/Apropos', {
  pageTitle: 'TopFrench-Learning A propos',
  path: '/Apropos'
});
};
exports.getNousContacter = (req, res, next) => {
  res.render('fr/nouscontacter', {
    pageTitle: 'TopFrench-Learning Nous Contacter',
    path: '/nouscontacter'
  });
  };